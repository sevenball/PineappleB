package com.wangshiqi.pineappleb.ui.fragment;

import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.wangshiqi.pineappleb.R;

/**
 * Created by dllo on 16/10/28.
 */
public class AnimFragment extends AbsFragment {
    private ImageView loadAnimIv;

    public static AnimFragment newInstance() {
        
        Bundle args = new Bundle();
        
        AnimFragment fragment = new AnimFragment();
        fragment.setArguments(args);
        return fragment;
    }
    
    @Override
    protected int setLayout() {
        return R.layout.fragment_anim;
    }

    @Override
    protected void initView() {
        loadAnimIv = byView(R.id.load_anim_iv);
    }

    @Override
    protected void initDatas() {
        AnimationDrawable drawable = (AnimationDrawable) loadAnimIv.getBackground();
        drawable.start();
    }
}
