package com.wangshiqi.pineappleb.utils;

/**
 * Created by dllo on 16/10/28.
 */
public interface OnAnimFinishedListener{
    void onAnimFinish();
}
