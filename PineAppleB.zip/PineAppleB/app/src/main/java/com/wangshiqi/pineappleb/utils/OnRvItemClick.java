package com.wangshiqi.pineappleb.utils;

/**
 * Created by dllo on 16/10/19.
 * Rv点击事件接口
 */
public interface OnRvItemClick<T> {
    void onRvItemClickListener(int position, T t);
}
