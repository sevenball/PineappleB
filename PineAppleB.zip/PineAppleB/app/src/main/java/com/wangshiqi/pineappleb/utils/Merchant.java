package com.wangshiqi.pineappleb.utils;

/**
 * Created by siqi on 16/3/31.
 *
 * @author siqi
 */
public class Merchant {

    public static final String MERCHANT_NO = "m1604080001";

    public static final String MERCHANT_NOTIFY_URL = "http://api.fuqian.la/services/notify";

    public static final String RSA_PRIVATE_KEY = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAL7VwBEXCDquwFz2tT2oCyyq1yAKX5rWxfEKVnpIz3kRNelPvkmm8jSleq1GlpyC1cngrJ59qmvchj4D43iIXvUX66d3A/7vA+kBq6asgFDPztvEBqjKcJuP26jHicKD9DDgv5tZw3nE0tIXBD0S2sr6+rha5KsmS9o4tPLXh/sLAgMBAAECgYEAoHPadMQX0DdkWAW656dmFd1i2Xa/YdIZRgy6H0Ee6J1W5d99kDHFTgygtBY4xkmfdYjpuqzQYLZfTL86P/rxUs4y5Z6xStQRigwwtpVkSY+lENicM9llvbG4Qz1lAfF2Od6KUin5HLEDHZI7CG5nqOG1JSLJtKgyQc6oW8BkF9ECQQD2agi68C6+3fB4aeb9ycgaydIOqAPZmj+AO2OhtEY5OHF5M8sqwbYxiahkxD9zu3SY0G3xYkIZ5LmWjIexkc0ZAkEAxkI4E8z3YPXj9NGMSiZQMgNi6QM/xSLCloqmBkhogMqp+DnmKDfQtpTH1HfscaAO/AHxNlTepQArvybenNXpwwJAa8RX6Rnd98+suZznTxsOjtixK4PDm0lgeD6BBlmHVMMgrXc/ZYWunt+ra9aAQac8CREu5CCq9BQaLoNrXPd9EQJARWTKMgwNDnAisP9jplSQv2C2Dy8m8/59s6mmAQ75HRNSuOKzL6KRuEaNR04OgZrvg7++STEdmQ1dQpP9WVH6dwJBAObQq3tfc2L0anzKRtZrKB9bbMVusQ+S6C6KBgLEkor0WB+tje9QaN0u/yu5Sxhr2yds2y2sHQc8im5FejxyaIg=";

}
