package com.wangshiqi.pineappleb.model.db;

/**
 * Created by dllo on 16/10/17.
 */
public class A {
}
