package com.wangshiqi.pineappleb.model.bean.focus;

import java.util.List;

/**
 * Created by dllo on 16/10/22.
 */
public class DiscussBean {

    /**
     * status : 1
     * msg :
     * success : true
     * totalCommentCount : 395
     * data : [{"id":14770369864871,"roomId":0,"userId":-2291018134358057703,"userIdStr":"-2291018134358057703","nick":"没死不代表我活着T^T","avatar":"http://q.qlogo.cn/qqapp/100374397/FC930F9AE5CF5F671E506859E72AEC8B/100","content":"哈哈哈","supportCount":0,"commentCount":0,"createTime":1477123632000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770369864861,"roomId":0,"userId":-2291018134358057703,"userIdStr":"-2291018134358057703","nick":"没死不代表我活着T^T","avatar":"http://q.qlogo.cn/qqapp/100374397/FC930F9AE5CF5F671E506859E72AEC8B/100","content":"哈哈哈","supportCount":0,"commentCount":0,"createTime":1477123628000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770368399021,"roomId":0,"userId":-2291018134358057703,"userIdStr":"-2291018134358057703","nick":"没死不代表我活着T^T","avatar":"http://q.qlogo.cn/qqapp/100374397/FC930F9AE5CF5F671E506859E72AEC8B/100","content":"哈哈哈","supportCount":0,"commentCount":0,"createTime":1477123478000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770368398881,"roomId":0,"userId":2991635508484785735,"userIdStr":"2991635508484785735","nick":"BOBOyQrfm","avatar":"http://img2.cache.netease.com/bobo/image/avatar150.png","content":"真的可以看第四集诶！","supportCount":0,"commentCount":0,"createTime":1477122873000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770368398271,"roomId":0,"userId":1207987402647404704,"userIdStr":"1207987402647404704","nick":"总攻立早大人","avatar":"http://bobo-public.nosdn.127.net/bobo_1460728695357_31504479","content":"莫名的柯南即视感","supportCount":1,"commentCount":0,"createTime":1477122422000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"要啥自行车"},{"id":14770369864361,"roomId":0,"userId":4701853730239072874,"userIdStr":"4701853730239072874","nick":"_柠汐酱_","avatar":"http://bobo-public.nosdn.127.net/bobo_1477120666803_14767917.png","content":"希望剧情。希望有后续","supportCount":0,"commentCount":1,"createTime":1477122164000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"萌新一只，请多指教☆～"},{"id":14770368398001,"roomId":0,"userId":8825975301258418311,"userIdStr":"8825975301258418311","nick":"liufuyang919","avatar":"http://img2.cache.netease.com/bobo/image/avatar150.png","content":"连环套","supportCount":0,"commentCount":0,"createTime":1477121789000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770369863901,"roomId":0,"userId":8825975301258418311,"userIdStr":"8825975301258418311","nick":"liufuyang919","avatar":"http://img2.cache.netease.com/bobo/image/avatar150.png","content":"大结局啊","supportCount":0,"commentCount":0,"createTime":1477121412000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770368397431,"roomId":0,"userId":8825975301258418311,"userIdStr":"8825975301258418311","nick":"liufuyang919","avatar":"http://img2.cache.netease.com/bobo/image/avatar150.png","content":"来看大结局的~","supportCount":0,"commentCount":0,"createTime":1477120520000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770369862421,"roomId":0,"userId":-6869781606456239262,"userIdStr":"-6869781606456239262","nick":"逸国大小姐的护法","avatar":"http://tva2.sinaimg.cn/crop.92.164.296.296.180/0065NbKujw8f8sdi9v7daj30dw0iigm0.jpg","content":"影子","supportCount":0,"commentCount":0,"createTime":1477118702000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770368396661,"roomId":0,"userId":-6869781606456239262,"userIdStr":"-6869781606456239262","nick":"逸国大小姐的护法","avatar":"http://tva2.sinaimg.cn/crop.92.164.296.296.180/0065NbKujw8f8sdi9v7daj30dw0iigm0.jpg","content":"看看","supportCount":0,"commentCount":0,"createTime":1477118690000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770369862381,"roomId":0,"userId":-6869781606456239262,"userIdStr":"-6869781606456239262","nick":"逸国大小姐的护法","avatar":"http://tva2.sinaimg.cn/crop.92.164.296.296.180/0065NbKujw8f8sdi9v7daj30dw0iigm0.jpg","content":"11","supportCount":0,"commentCount":0,"createTime":1477118684000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770369862371,"roomId":0,"userId":-6869781606456239262,"userIdStr":"-6869781606456239262","nick":"逸国大小姐的护法","avatar":"http://tva2.sinaimg.cn/crop.92.164.296.296.180/0065NbKujw8f8sdi9v7daj30dw0iigm0.jpg","content":"11","supportCount":0,"commentCount":0,"createTime":1477118680000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770369862261,"roomId":0,"userId":-6869781606456239262,"userIdStr":"-6869781606456239262","nick":"逸国大小姐的护法","avatar":"http://tva2.sinaimg.cn/crop.92.164.296.296.180/0065NbKujw8f8sdi9v7daj30dw0iigm0.jpg","content":"1111","supportCount":0,"commentCount":0,"createTime":1477118655000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"},{"id":14770368396411,"roomId":0,"userId":1611364521720206519,"userIdStr":"1611364521720206519","nick":"徐啸天2050","avatar":"http://wx.qlogo.cn/mmopen/CkBYF6IYNs2gQ6ZIeJia2oMCLTuS8dgsqdVEKFeYh3Ayxb0vyZxliaRTAX83Yr3xtqic4CWTTATwBnF0YjFdkrppOHLsIRymWr6/0","content":"好","supportCount":0,"commentCount":0,"createTime":1477118148000,"hasSupport":false,"images":null,"commentFrom":0,"intro":"主人犯懒，什么都没写"}]
     */

    private int status;
    private String msg;
    private boolean success;
    private int totalCommentCount;
    /**
     * id : 14770369864871
     * roomId : 0
     * userId : -2291018134358057703
     * userIdStr : -2291018134358057703
     * nick : 没死不代表我活着T^T
     * avatar : http://q.qlogo.cn/qqapp/100374397/FC930F9AE5CF5F671E506859E72AEC8B/100
     * content : 哈哈哈
     * supportCount : 0
     * commentCount : 0
     * createTime : 1477123632000
     * hasSupport : false
     * images : null
     * commentFrom : 0
     * intro : 主人犯懒，什么都没写
     */

    private List<DataBean> data;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public int getTotalCommentCount() {
        return totalCommentCount;
    }

    public void setTotalCommentCount(int totalCommentCount) {
        this.totalCommentCount = totalCommentCount;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        private long id;
        private int roomId;
        private long userId;
        private String userIdStr;
        private String nick;
        private String avatar;
        private String content;
        private int supportCount;
        private int commentCount;
        private long createTime;
        private boolean hasSupport;
        private Object images;
        private int commentFrom;
        private String intro;

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public int getRoomId() {
            return roomId;
        }

        public void setRoomId(int roomId) {
            this.roomId = roomId;
        }

        public long getUserId() {
            return userId;
        }

        public void setUserId(long userId) {
            this.userId = userId;
        }

        public String getUserIdStr() {
            return userIdStr;
        }

        public void setUserIdStr(String userIdStr) {
            this.userIdStr = userIdStr;
        }

        public String getNick() {
            return nick;
        }

        public void setNick(String nick) {
            this.nick = nick;
        }

        public String getAvatar() {
            return avatar;
        }

        public void setAvatar(String avatar) {
            this.avatar = avatar;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public int getSupportCount() {
            return supportCount;
        }

        public void setSupportCount(int supportCount) {
            this.supportCount = supportCount;
        }

        public int getCommentCount() {
            return commentCount;
        }

        public void setCommentCount(int commentCount) {
            this.commentCount = commentCount;
        }

        public long getCreateTime() {
            return createTime;
        }

        public void setCreateTime(long createTime) {
            this.createTime = createTime;
        }

        public boolean isHasSupport() {
            return hasSupport;
        }

        public void setHasSupport(boolean hasSupport) {
            this.hasSupport = hasSupport;
        }

        public Object getImages() {
            return images;
        }

        public void setImages(Object images) {
            this.images = images;
        }

        public int getCommentFrom() {
            return commentFrom;
        }

        public void setCommentFrom(int commentFrom) {
            this.commentFrom = commentFrom;
        }

        public String getIntro() {
            return intro;
        }

        public void setIntro(String intro) {
            this.intro = intro;
        }
    }
}
