package com.wangshiqi.pineappleb.model.bean.dicovery;

/**
 * Created by dllo on 16/10/19.
 */
public class HeadBean {


    /**
     * id : 14769800942881
     * type : 2
     * title : 【午夜福利】食色性也
     * cover : http://bobo-public.nosdn.127.net/bobo_1476985648216_61808555.gif
     * videoId : -1
     * url : http://bolo.bobo.com/m/hybrid/collection/details?aid=14769800942761&From=21night
     * priority : null
     * isTop : 0
     * topBeginTime : null
     * topEndTime : null
     * tag : 午夜福利
     * onlineTime : null
     * offlineTime : null
     * createId : -9052032363940768495
     * createTime : 1476985648000
     * link :
     * linkMp4 :
     * duration : 0
     * liveId : null
     * isLock : null
     * previewDuration : 0
     * unlockSeed : 0.0
     * unlockCount : null
     */

    private long id;
    private int type;
    private String title;
    private String cover;
    private long videoId;
    private String url;
    private Object priority;
    private int isTop;
    private Object topBeginTime;
    private Object topEndTime;
    private String tag;
    private Object onlineTime;
    private Object offlineTime;
    private long createId;
    private long createTime;
    private String link;
    private String linkMp4;
    private int duration;
    private Object liveId;
    private Object isLock;
    private int previewDuration;
    private double unlockSeed;
    private Object unlockCount;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCover() {
        return cover;
    }

    public void setCover(String cover) {
        this.cover = cover;
    }

    public long getVideoId() {
        return videoId;
    }

    public void setVideoId(long videoId) {
        this.videoId = videoId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Object getPriority() {
        return priority;
    }

    public void setPriority(Object priority) {
        this.priority = priority;
    }

    public int getIsTop() {
        return isTop;
    }

    public void setIsTop(int isTop) {
        this.isTop = isTop;
    }

    public Object getTopBeginTime() {
        return topBeginTime;
    }

    public void setTopBeginTime(Object topBeginTime) {
        this.topBeginTime = topBeginTime;
    }

    public Object getTopEndTime() {
        return topEndTime;
    }

    public void setTopEndTime(Object topEndTime) {
        this.topEndTime = topEndTime;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public Object getOnlineTime() {
        return onlineTime;
    }

    public void setOnlineTime(Object onlineTime) {
        this.onlineTime = onlineTime;
    }

    public Object getOfflineTime() {
        return offlineTime;
    }

    public void setOfflineTime(Object offlineTime) {
        this.offlineTime = offlineTime;
    }

    public long getCreateId() {
        return createId;
    }

    public void setCreateId(long createId) {
        this.createId = createId;
    }

    public long getCreateTime() {
        return createTime;
    }

    public void setCreateTime(long createTime) {
        this.createTime = createTime;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getLinkMp4() {
        return linkMp4;
    }

    public void setLinkMp4(String linkMp4) {
        this.linkMp4 = linkMp4;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public Object getLiveId() {
        return liveId;
    }

    public void setLiveId(Object liveId) {
        this.liveId = liveId;
    }

    public Object getIsLock() {
        return isLock;
    }

    public void setIsLock(Object isLock) {
        this.isLock = isLock;
    }

    public int getPreviewDuration() {
        return previewDuration;
    }

    public void setPreviewDuration(int previewDuration) {
        this.previewDuration = previewDuration;
    }

    public double getUnlockSeed() {
        return unlockSeed;
    }

    public void setUnlockSeed(double unlockSeed) {
        this.unlockSeed = unlockSeed;
    }

    public Object getUnlockCount() {
        return unlockCount;
    }

    public void setUnlockCount(Object unlockCount) {
        this.unlockCount = unlockCount;
    }
}
