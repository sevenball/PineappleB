package com.wangshiqi.pineappleb.model.bean.dicovery;

/**
 * Created by dllo on 16/10/24.
 */
public class MustWatchBean {
    /**
     * position : 0
     * id : 144
     * dataType : 0
     * bannerTag : 福利活动
     * bannerPic : http://bobo-public.nosdn.127.net/bobo_1477282039720_30158509.png
     * status : 1
     * bannerLink : http://www.bobo.com/16/1021/11/C3T9IGM0003500MA.html?bid=144
     * bannerName : 菠萝半岁大放送
     * priority : 0
     * videoId : 0
     * type : 1
     */

    private int position;
    private int id;
    private int dataType;
    private String bannerTag;
    private String bannerPic;
    private int status;
    private String bannerLink;
    private String bannerName;
    private int priority;
    private int videoId;
    private int type;

    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getDataType() {
        return dataType;
    }

    public void setDataType(int dataType) {
        this.dataType = dataType;
    }

    public String getBannerTag() {
        return bannerTag;
    }

    public void setBannerTag(String bannerTag) {
        this.bannerTag = bannerTag;
    }

    public String getBannerPic() {
        return bannerPic;
    }

    public void setBannerPic(String bannerPic) {
        this.bannerPic = bannerPic;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getBannerLink() {
        return bannerLink;
    }

    public void setBannerLink(String bannerLink) {
        this.bannerLink = bannerLink;
    }

    public String getBannerName() {
        return bannerName;
    }

    public void setBannerName(String bannerName) {
        this.bannerName = bannerName;
    }

    public int getPriority() {
        return priority;
    }

    public void setPriority(int priority) {
        this.priority = priority;
    }

    public int getVideoId() {
        return videoId;
    }

    public void setVideoId(int videoId) {
        this.videoId = videoId;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
